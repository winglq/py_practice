print 'foo.py'

